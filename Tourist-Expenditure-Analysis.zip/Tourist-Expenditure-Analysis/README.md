# Tourist-Expenditure-Analysis
This is an analysis of tourist expenditure. The data was randomly generated using python's random module.Python libraries were used.
